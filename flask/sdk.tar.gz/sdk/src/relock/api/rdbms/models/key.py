from ..rsa import RSA

class Key(RSA):

	pass