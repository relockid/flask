from ..logic import Logic

class Config(Logic):

	def __int__(self):
		return int(self.value)