HTMLCollection.prototype.forEach = Array.prototype.forEach;

"use strict";
var Passkeys = (() => {

	var __defProp = Object.defineProperty;
	var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
	var __getOwnPropNames = Object.getOwnPropertyNames;
	var __hasOwnProp = Object.prototype.hasOwnProperty;

	var __export = (target, all) => {
		for (var name in all)
			__defProp(target, name, { get: all[name], enumerable: true });
	};
	var __copyProps = (to, from, except, desc) => {
		if (from && typeof from === "object" || typeof from === "function") {
			for (let key of __getOwnPropNames(from))
				if (!__hasOwnProp.call(to, key) && key !== except)
					__defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
		}
		return to;
	};
	var __toCommonJS = (mod2) => __copyProps(__defProp({}, "__esModule", { value: true }), mod2);
	var input_exports = {};

	class Passkeys {

		constructor(power = 128, ...args){
			document.addEventListener("DOMContentLoaded", function(event) {
				console.log('Passkeys.')
			}.bind(this));
		}

		// register / create a new credential
		async register() {
			window.relock.request('/relock/register', {id: null})
				.then((response) => response.json())
				.then((options) => {
					// Registration args object
					let args = {
						publicKey: {
								rp: {
									id: options.rp.id,
									name: options.rp.name
								},
								authenticatorSelection: options.authenticatorSelection,
								user: {
									id: options.user.id.base64url_decode(),
									name: options.user.name,
									displayName: options.user.displayName
								},
								pubKeyCredParams: options.pubKeyCredParams,
								// attestation: options.attestation,
								timeout: parseInt(options.timeout),
								challenge: options.challenge.base64url_decode()
						}
					};

					navigator.credentials.create(args)
						.then((credential) => {
							// convert credential to json serializeable
							const serializeable = {
									authenticatorAttachment: credential.authenticatorAttachment,
									id: credential.id,
									rawId: credential.rawId.base64url_encode(),
									response: {
										attestationObject: credential.response.attestationObject.base64url_encode(),
										clientDataJSON: credential.response.clientDataJSON.base64url_encode()
									},
									type: credential.type
							};
							this.store(serializeable)
						}).catch((err) => {
							console.log("ERROR", err);
						})
				}).catch((error) => {
					console.error('Registration of credential Faild.', error)
				});
		}

		// register / create a new credential
		async store(credential) {
			window.relock.request('/relock/register', {credential: credential})
				.then((response) => response.json())
				.then((json) => {
					document.dispatchEvent(
						new CustomEvent('XPasskeyCreated', {bubbles: true, 
													 		detail:{ id: new Uint8Array(json.id) }}));
				}).catch((error) => {
					console.error('Storage of credential Faild.')
				});
		}

		async authenticate(credential) {
			window.relock.request('/relock/authenticate', {id: credential})
				.then((response) => response.json())
				.then((json) => {
					// Login args object
					const args = {
						publicKey: json,
					};

					if(args.publicKey.allowCredentials.length)
						args.publicKey.allowCredentials[0].id = args.publicKey.allowCredentials[0].id.base64url_decode();
					args.publicKey.challenge = args.publicKey.challenge.base64url_decode()

					return navigator.credentials.get(args)
							.then((credential) => {
								// convert credential to json serializeable
								const serializeable = {
										authenticatorAttachment: credential.authenticatorAttachment,
										id: credential.id,
										rawId: credential.rawId.base64url_encode(),
										response: {
										authenticatorData: credential.response.authenticatorData.base64url_encode(),
												clientDataJSON: credential.response.clientDataJSON.base64url_encode(),
												signature: credential.response.signature.base64url_encode(),
												userHandle: credential.response.userHandle.base64url_encode(),
										},
										type: credential.type
								};

								this.signin(serializeable);
							})
							.catch((err) => {
								console.log("ERROR", err);
							});
				 })
				.catch((error) => {
					console.error(error)
				 });
		}

		async signin(credential) {
			window.relock.request('/relock/authenticate', {credential: credential})
				.then((response) => response.json())
				.then((json) => {
					console.info('User passkey signature is correct.')
					document.dispatchEvent(new CustomEvent('XPasskeyAuthenticated', {bubbles: true, 
													 					  	  		 detail:{ id: new Uint8Array(json.id) }}));
				 })
				.catch((error) => {
					console.error('Registration of credential Faild.')
				 });
		}
	}

	let object = undefined

	try {
		object = new Passkeys()
	}
	catch(err) {
		console.error('Fatal object start.')
	}
	finally{
		if(object){
			__export(input_exports, {
				register:    () => object.register.bind(object),
				authenticate:() => object.authenticate.bind(object),
				public:      () => object.public
			});

			return __toCommonJS(input_exports);
		}
	}
})();

