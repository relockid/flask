HTMLCollection.prototype.forEach = Array.prototype.forEach;

const observer = new PerformanceObserver((list) => {
	list.getEntries().forEach((entry) => {
		console.log(
			'The time to ' + entry.name + ' was %c' + Math.round(entry.startTime), "color: #bada55", 'milliseconds.',
		);
	});
});

observer.observe({ type: "paint", buffered: true }, {type: "navigation", buffered: true});

window.addEventListener('load', (event) => {
	let time = window.performance.timing;
	let pageloadtime = time.loadEventStart - time.navigationStart;
	console.log(
		'The time to interactive was %c' + Math.round(pageloadtime), "color: #bada55", `milliseconds.`,
	);
});

document.addEventListener("DOMContentLoaded", (event) => {
	let time = window.performance.timing;
	let speed = time.domInteractive - time.domLoading;
	console.log(
		'The DOMContentLoaded take %c' + speed, "color: #bada55", `milliseconds.`,
	);
});

console.image = async function(url, size = 100) {
	const image = new Image();
	image.src = url;
	image.onload = function() {
		var style = [
			'font-size: 1px;',
			'padding: ' + this.height/100*size + 'px ' + this.width/100*size + 'px;',
			'background: url('+ url +') no-repeat;',
			'background-size: contain;'
		 ].join(' ');
		 console.log('%c ', style);
	};
};

const url = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAAA4CAMAAAA8cK3qAAAAjVBMVEVHcEzy7+329vf+/v7r4Nv8/f3+/v77+/vr5uX5+fn09fX19fb7+/z+/v78/P3+/v7////8/Pz6+vr4+Pnv7/D+/v7+/v7+/v79/f76+vr/kU3+/v79/f36+vv7+/v4+Pj9/f37+/v6+vr8/Pz9/f3vjEz2j033j0z9kU38kU33j035kE34kE3///9HcEwi/9nXAAAAL3RSTlMAEByPCnb8iQSQJ3FwscXu9n5ULk/nvODOR/7YmGlhM6Y4Pp6cIV6B492Xk4v/AMZKE0YAAAKnSURBVFjD7ZbZdqMwDIZt4wCBmJ0ABQKhaTub3//1RrJZQsgyF72Zc/zfsMn6JEtWQoiRkZGRkdEkl3PufpPVQ7VBECQvrfx/snooR0q5e2m1B6uDgXwHxEURQpnuDOp1Hn0Cuf3usjTVS2fI6PFamRDixE9BwNDFIcjDPNixBxAvLlff3awvwrAWibtAWAMe/TXFh28Xy5Y1LPSOUuvo3YUM5fg96HRaVqSfI4fPELTOz2QDyW2JEIaMKMSFgt6BpLWcVGIUrjM/9zOkCsFHS7YQKQthURJjjEmaBHBttxC3h2to+Q24kRbR/mTttE1Yp9N2MVz8zu9A7MaDUjEItEgx4gI2jG4gZ4zxBM8HSLzwNLTEBVU1F96Z0txAhCInsLZR7y4QcbqB7LBYaEmxNCfiQSxRsm5hTC7cDhd/zJ2o3bLOwzCcG0guuYWowGP1woK7PakiVclriIOb5bhPIA2WHeoeRtG6KBrCjyp+FObUk9OU2QLBDspT8gKyaHcPYmvIYYaINUQpfgZBq6Mzadhsl5jnBm7su6phSW8gmEr3BNKqnX48u/bKNSFTdbDbwm4NEb0+NA8huGgspP6Jcz+/PvkCSXTnEtLlULxKN5mFlpSOkDpN81XLbSAc96MHCh+EMvt6e3v7WiAMnYqUdtgBAdW7FsWMpn3DNSTWl4A9hIwn+N0SocQj/PEDID8/lrHS2thAZS7HYBVVFvAC58g4VvD0bGp/BSGHaOqQMLsD4db02dZnoSqmFzAgpgGJ+RU3tfdt257K7SalrYbqsQIn7m+A/IEbB0xUR9NYe60PY2nPQoUVCZi6e7Dy8eeghJub6cWyLFtmDUucSxNXujHp5y9VeG8x8Vrrsj8t9rSKm4u2RytViw5uBm7+SRoZGRkZ/V/6CyFVcb3QgLeDAAAAAElFTkSuQmCC'
console.image(url, 23);

"use strict";
var relock = (() => {

	var __defProp = Object.defineProperty;
	var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
	var __getOwnPropNames = Object.getOwnPropertyNames;
	var __hasOwnProp = Object.prototype.hasOwnProperty;

	var __export = (target, all) => {
		for (var name in all)
			__defProp(target, name, { get: all[name], enumerable: true });
	};
	var __copyProps = (to, from, except, desc) => {
		if (from && typeof from === "object" || typeof from === "function") {
			for (let key of __getOwnPropNames(from))
				if (!__hasOwnProp.call(to, key) && key !== except)
					__defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
		}
		return to;
	};
	var __toCommonJS = (mod2) => __copyProps(__defProp({}, "__esModule", { value: true }), mod2);
	var input_exports = {};

	class Montgomery{

		x25519   = nobleCurves.x25519
		ed25519  = nobleCurves.ed25519

		constructor(key){
			this.private = nobleCurves.ed25519_edwardsToMontgomeryPriv(key);
			this.public = nobleCurves.ed25519_edwardsToMontgomeryPub(this.ed25519.getPublicKey(key));
		}

		secret(key){
			return this.x25519.getSharedSecret(this.private, key)
		}
	}

	class Signature{

		ed25519  = nobleCurves.ed25519

		constructor(key){
			if(!key.length)
				this.private = this.ed25519.utils.randomPrivateKey();
			else
				this.private = key;
			this.public = this.ed25519.getPublicKey(this.private)
		}

		bytes(){
			return this.private
		}
	}

	class Idle {
			constructor(timeout = 10, idleCallback = null, backToActiveCallback = null) {
					this.timeout = timeout * 1000
					this.timestamp = new Date()
					this.idleCallback = idleCallback
					this.backToActiveCallback = backToActiveCallback
					this.idle = false
					this.timer = null
					this.events = ['scroll', 'mousemove', 'touchstart', 'focus']
					console.info('Initiate activity monitoring and re-keying engine.')
			let timestamp = document.querySelector("meta[name='x-key-timestamp']")
			if(timestamp === null)
				timestamp = String()
			if(!!timestamp) {
				if(!!timestamp.getAttribute("content"))
					timestamp = timestamp.getAttribute("content")
				else
					timestamp = String()
				if(timestamp)
					this.timestamp = new Date(parseInt(timestamp) * 1000)
			}
			window.addEventListener('visibilitychange', function(event) {
				if(!document.hidden){
					if(new Date() - this.timestamp > this.timeout) {
						this.goIdle()
					}
					this.processTimestamp()
				}
			}.bind(this), false);
					this.init()
			}

			init() {
					this.events.forEach(name => {
						window.addEventListener(name, this.processTimestamp, true)
					})

					this.interval = setInterval(() => {
						if(new Date() - this.timestamp > this.timeout) {
							this.goIdle()
						}
					}, 1000)
			}

			goIdle = () => {
				if(!this.idle){
						this.idle = true
				document.dispatchEvent(new CustomEvent('XSiteIdle', {bubbles: true, 
																	 detail:{ timeout: this.timeout / 1000 }}));
				}
			}

			processTimestamp = (event) => {
				if(this.idle) {
					this.timestamp = new Date()
					this.idle = false
					document.dispatchEvent(new CustomEvent('XSiteActive', {bubbles: true}));
				}
			}
	}

	class Storage{

		__session   = new Uint8Array()
		__tesseract = new Uint8Array()

		constructor(...args){
			if(args[0] && args[0].length === 32){
				this.session = new Uint8Array(args[0])
			} else if(args[0] && args[0].length !== 32){
				this.session = new Uint8Array()
			}
			if(args[1] && args[1].length === 32) {
				new GCM(args[1]).decrypt(this.get('tesseract'))
					.then((tesseract) => {
						if(tesseract.length !== 0) {
							this.__tesseract = tesseract
							document.dispatchEvent(new CustomEvent('XKeyReady', {bubbles: true, detail:{ obj: true }}));
						} else {
							console.log('Recovery wrong key!');
							this.secret = nobleHashes.utils.randomBytes(128)
						}
					})
			} else if(this.established && this.__tesseract.length === 0) {
				console.log('Restored. Try to gain access to the local storage area.')
				this.session.decrypt(this.get('tesseract'))
					.then((tesseract) => {
						if(tesseract.length !== 0)
							this.__tesseract = tesseract
						document.dispatchEvent(new CustomEvent('XKeyReady', {bubbles: true, detail:{ obj: true }}));
					});
			}
		}

		get signer() {
			return this.get('signature').slice(0, 32)
		}

		set signer(key) {
			if(key && key.length)
				return this.set('signature', key)
			return this.signer
		}

		get client() {
			return this.get('client').slice(0, 32)
		}

		set client(key) {
			if(key && key.length)
				return this.set('client', key)
			return this.client
		}

		get xsid() {
			if(!localStorage.hasOwnProperty('xsid'))
				localStorage.setItem('xsid', new Uint8Array().hexlify())
			return localStorage.getItem('xsid').unhexlify()
		}

		set xsid(key) {
			if(key && key.length)
				localStorage.setItem('xsid', new Uint8Array(key).hexlify())
			return this.xsid
		}

		get secret() {
			return this.__tesseract
		}

		set secret(key) {
			this.__tesseract = key
			this.session.encrypt(key).then((encrypted) => {
				this.set('tesseract', encrypted)
				this.set('stamp', nobleHashes.blake2b(key, {salt: new Uint8Array(16), 
																dkLen: 16}))
				this.signer = this.__signature // save signature with new session
				document.dispatchEvent(new CustomEvent('XKeyReady', {bubbles: true, detail:{ obj: true }}));
				// this.session.decrypt(this.get('tesseract')).then((decrypted) => {
				// 	console.log('decrypt test', decrypted)
				// });
				// console.log('%c Oh my heavens! ', 'background: #222; color: #bada55', '%c We got match!', 'background: #222; color: #ff6600',);
				// console.log("%cI am red %cI am green", "color: #bada55", "color: green");
				console.log('Current Transient Key stamp:' + ' %c' + this.hash.hexlify(), "color: #bada55")
				console.log('Current Transient Key size is', this.__tesseract.length, 'bytes')
			});
		}

		get(name) {
			if(!localStorage.hasOwnProperty(name))
				localStorage.setItem(name, new Uint8Array().hexlify())
			return localStorage.getItem(name).unhexlify()
		}

		set(name, value) {
			if(value && value.length)
				localStorage.setItem(name, new Uint8Array(value).hexlify())
			return this.get(name)
		}

		get session() {
			if(!sessionStorage.hasOwnProperty('relock'))
				sessionStorage.setItem('relock', new Uint8Array().hexlify())
			if(this.__session.length !== 32)
				this.__session = sessionStorage.getItem('relock').unhexlify()
			if(this.__session.length === 32)
				return new GCM(this.__session.slice(0,32))
			return false
		}

		set session(key) {
			if(key.length) {
				sessionStorage.setItem('relock', new Uint8Array(key).hexlify())
			} else {
				sessionStorage.removeItem('relock')
				this.__session = new Uint8Array()
				this.__tesseract = new Uint8Array()
			}
			return this.session
		}

		get established() {
			if(this.session)
				return true
			return false
		}

		get hash() {
			if(this.get('stamp').length !== 0)
				return this.get('stamp')
			return new Uint8Array()
		}

		clear() {
			localStorage.removeItem('signature')
			localStorage.removeItem('tesseract')
			localStorage.removeItem('server')
			localStorage.removeItem('stamp')
			localStorage.removeItem('client')
			localStorage.removeItem('xsid')
			sessionStorage.removeItem('relock')
			sessionStorage.removeItem('screen')
		}
	}

	class relock{

		ed25519  = nobleCurves.ed25519
		HKDF     = nobleHashes.hkdf
		blake    = nobleHashes.blake2b
		scrypt   = nobleHashes.scrypt
		random   = nobleHashes.utils.randomBytes

		__storage     = undefined
		__x25519      = undefined
		__signer      = undefined
		__established = false
		__XSiteIdle   = undefined
		__screen      = new Uint8Array()

		__refactor    = String()

		constructor(power = 128, ...args){

			this.nonce   = this.random(16)
			this.power   = power

			this.startLoading = window.performance.now()
			this.channel = new BroadcastChannel('tab-notifications');
			
			this.private = this.ed25519.utils.randomPrivateKey()
			this.public  = this.ed25519.getPublicKey(this.private)

			let xsid     = document.meta('xsid')
			let screen   = document.meta('screen')

			if(!this.screen.equal(screen) || !this.xsid.equal(xsid))
				this.__storage = new Storage(new Uint8Array())
			else
				this.__storage = new Storage(...args)

			this.__x25519    = new Montgomery(this.private)
			this.__signer    = new Signature(this.signer || this.private)
			
			if(!this.screen.equal(screen)){
				this.tab = new FormData()
				this.tab.append('origin', document.location.origin)
				this.tab.append('path', document.location.pathname)
				this.tab.append('screen', this.screen.hexlify())
				this.tab.append('wrong', screen.hexlify())
				navigator.sendBeacon('/relock/screen', this.tab)
			}

			document.addEventListener('XReKeying', function(event) {
				document.getElementsByClassName("keygen").forEach((el) => {
					el.style.visibility = "visible";
				});
			}.bind(this));

			document.addEventListener('XReKeyingStop', function(event) {
				setTimeout(() => {
					document.getElementsByClassName("keygen").forEach((el) => {
						el.style.visibility = "hidden";
					});
				}, 500)
			}.bind(this));

			document.addEventListener('XKeyValidate', this.KeyValidate.bind(this));
			document.addEventListener('XKeyReady', this.KeyReady.bind(this));

			document.addEventListener("DOMContentLoaded", function(event) {
				console.log('xsid is correct?', this.xsid.equal(xsid))
				console.log('screen is correct?', this.screen.equal(screen))
				if(!this.__storage.established)
					this.exchange()
			}.bind(this));

			window.addEventListener('beforeunload', function(event) {
				this.unload = new FormData()
				this.unload.append('screen', this.screen.hexlify())
				this.unload.append('origin', document.location.origin)
				this.unload.append('path', document.location.pathname)
			}.bind(this));

			window.addEventListener('visibilitychange', function(event) {
				if(document.hidden && this.unload)
					navigator.sendBeacon('/relock/close', this.unload)
			}.bind(this));

			window.addEventListener('XPasskeyCreated', function(event) {
				console.log(event)
			}.bind(this));
		}

		get id(){
			return this.client.hexlify()
		}

		get screen(){
			if(!sessionStorage.hasOwnProperty('screen'))
				sessionStorage.setItem('screen', this.random(16).hexlify())
			return sessionStorage.getItem('screen').unhexlify()
		}

		set screen(value){
			sessionStorage.setItem('screen', value.hexlify())
		}

		get xsid(){
			if(!localStorage.hasOwnProperty('xsid'))
				localStorage.setItem('xsid', this.random(32).hexlify())
			return localStorage.getItem('xsid').unhexlify()
		}

		get established () {
			return this.__established
		}

		get session(){
			return this.__storage.session
		}

		get secret(){
			return this.__storage.secret
		}

		get client(){
			return this.__storage.client
		}

		get signer(){
			return this.__storage.signer
		}

		get hash(){
			return this.__storage.hash
		}

		set credential(value) {
			navigator.credentials.create({
				password: {
					id: window.location.origin,     // The username or unique identifier for the account
					name: "Account recovery code for",
					password: value,   // The password
					mediation: 'silent'
				}
			}).then(function (credential) {
				console.log("Credential created:", credential);
				// Store the credential securely for later use, or handle as needed
				// Store it
				navigator.credentials.store(credential).then(function () {
				  // continuation
				});
			}).catch(function (err) {
				console.log("Error creating credential:", err);
			});
		}

		async KeyReady(event){
			this.__signer = new Signature(this.__storage.signer)
			if(this.__refactor) {
				console.log('XKeyInProgress, got re-keying demand.')
				console.log('Mutation in progress...')
				if(this.rekeying(this.__refactor)){
					this.__refactor = String()
					console.log('Re-keying by factor Successful.')
				} else { //if(this.close()){
					this.__refactor = String()
					console.warn('Re-keying faild, can\'t verify token. Session destroyed...')
				}
			} else {
				console.info('XKeyReady, access to the storage is active.')
				console.log(
					'The time to access storage took %c' + Math.round(window.performance.now() - this.startLoading), "color: #bada55", `milliseconds.`,
				);
				this.startLoading = window.performance.now()
				document.dispatchEvent(new CustomEvent('XKeyValidate', {bubbles: true, 
																		detail:{ rekeying: true }}));
			}
		}

		async KeyValidate(event){
			// window.dispatchEvent(new CustomEvent('XReKeying', {bubbles: true, detail:{ obj: true }}));
			let nonce = document.meta('nonce')
			let signature = document.meta('signature')

			if(nonce && signature && this.verify(nonce, signature)) {
				console.log('Discovered valid signature of re-keying demand.')
				document.querySelector("meta[name='x-key-signature']").remove()
				if(this.rekeying(nonce))
					console.log('The rolling of the Transient key in progress.')
			} else {
				if(nonce)
					document.querySelector("meta[name='x-key-nonce']").remove()
				this.request('/relock/validate', {nonce: nonce,
												  screen: this.screen.hexlify()})
					.then((response) => response.json())
					.then((data) => {
							this.__established = data.status

							if(data.status){
								console.log('Token match the server side, confirm status:', data.status)
								console.log(
									'The time to confirm keys was %c' + Math.round(window.performance.now() - this.startLoading), "color: #bada55", `milliseconds.`,
								);
							} else if(data.reprocess){
								console.log('Data reprocess clear')
								return this.clear()
							}

							// window.Passkeys.register()

							console.log('Token established:', this.__established)
							document.dispatchEvent(new CustomEvent('XReKeyingStop', {bubbles: true, 
																						 detail:{ rekeying: false,
																								  authenticated: data.authenticated,
																								  credential: data.credential,
																								  owner: data.owner,
																								  valid: data.status }}));
							if(this.__established){
								console.log('User is authenticated:', data.authenticated)
								window.dispatchEvent(new CustomEvent('XKeyEstablished', {bubbles: true, 
																						 detail:{ rekeying: false,
																								  authenticated: data.authenticated,
																								  credential: data.credential,
																								  owner: data.owner,
																								  valid: data.status }}));
							} else {
								window.dispatchEvent(new CustomEvent('XKeyFailure', {bubbles: true, 
																					 detail:{ rekeying: false,
																							  authenticated: data.authenticated,
																							  credential: data.credential,
																							  owner: data.owner,
																							  valid: data.status }}));
							}
					 })
					.catch((error) => {
						console.error('Request validation failure:', error);
						document.dispatchEvent(new CustomEvent('XReKeyingStop', {bubbles: true, 
																					 detail:{ rekeying: false,
																								valid: false }}));
					 });
			}
		}

		async exchange(){
			document.dispatchEvent(new CustomEvent('XReKeying', {bubbles: true, detail:{ exchange: true }}));
			if(!this.established && !this.__storage.established)
				this.request('/relock/exchange', {hash: this.hash,
												   key: this.public,
												  xsid: this.xsid,
												screen: this.screen,
												 width: window.innerWidth,
												height: window.innerHeight})
					.then((response) => response.json())
					.then((message) => {
						let client  = new Uint8Array(message.key)
						console.log('Key agreement in progress...')
						// console.log('Client public', this.public)
						let x25519  = nobleCurves.ed25519_edwardsToMontgomeryPub(client)
						let secret  = this.__x25519.secret(x25519)
						let session = this.derive(secret)

						if(!this.__storage.hash.length){
							this.__storage.session = session
							this.__storage.xsid    = new Uint8Array(message.xsid)
							this.__storage.client  = new Uint8Array(message.signer)
							this.__storage.secret  = this.expand(session, this.power)
							this.__storage.signer  = this.private
							this.__signer          = new Signature(this.private)
							// console.log('Server key', this.__storage.client)
							// console.log('Client', this.__signer.public)
							console.log('New keys establishment of', this.__storage.secret.length, 'accomplished.')
						} else {
							console.log('Recovery key delivered. Try to decrypt storage.')
							new GCM(session).decrypt(new Uint8Array(message.recovery))
								.then(decrypted => {									// if(!new Uint8Array(message.token).empty())
									if(message.token.length)
										this.__refactor = message.token
									if(message.restore)
										this.__storage  = new Storage(decrypted, decrypted)
									else
										this.__storage  = new Storage(session, decrypted)
									this.__storage.xsid = new Uint8Array(message.xsid)
									this.__signer = new Signature(this.__storage.signer)

								})
								.catch((error) => {
									// console.log('Decryption wrong key!');
									// return new Uint8Array()
									console.log(error)
								});

						}
						console.log('Exchange accomplished.')
					 })
					.catch((error) => {
						document.dispatchEvent(new CustomEvent('XReKeyingStop', {bubbles: true, detail:{ exchange: true }}));
						console.error('Key agreement failure.')
						console.log(error)
						// this.clear()
					 });
		}

		async request(path, body) {
			for (let index in body) {
				if(body[index] !== null && body[index].constructor == Uint8Array)
					body[index] = Array.from(body[index])
			};
			let token = this.token()
			let signature = this.sign(token)
			// 	// body['X-Key-Token'] = Array.from(token)
			// 	// body['X-Key-Signature'] = Array.from(this.sign(token))
			return fetch(path, {
					method: 'POST',
					headers: {'Content-Type': 'application/json',
							  'accept': 'application/json',
							  'X-Key-Token': token.hexlify(),
							  'X-Key-Signature': signature.hexlify(),
							  'X-Key-Time': Math.round(+new Date()/1000),
							  'Access-Control-Allow-Credentials': 'true',
							  'X-CSRFToken': document.csrf()},
					credentials: 'include',
					body: JSON.stringify(body)
				})
		}

		close(){
			this.__storage.session = new Uint8Array()
			window.setTimeout(() => { window.location.href = '/' }, 100)
			return true
		}

		clear(redirect){
			// alert('clear');
			this.request('/relock/clear', {keys: true})
				.then((response) => response.json())
				.then((data) => {
						this.__storage.clear()
					// if(!redirect)
					// 	setTimeout(() => { window.location.href = '/' }, 100)
				 })
				.catch((error) => {
					console.error('Token validation failure:', error);
				 });
		}

		rekeying(salt = new Uint8Array(32),
				 token = new Uint8Array(32)) {
			if(salt.constructor === String)
				salt   = salt.unhexlify()
			if(!salt.empty() && salt.length > 32)
				token  = salt.slice(salt.length / 2, salt.length)
			if(salt.empty())
				salt   = this.random(salt.length)
			else if(salt.length > 32)
				salt   = salt.slice(0, salt.length / 2)
			this.__storage.secret = this.derive(this.secret, salt, this.secret.length)
			if(!token.empty())
				return this.validate(token)
			return salt.append(this.token()).hexlify()
		}

		derive(key, salt = new Uint8Array(32), 
					size = 32,
					info = 'handshake data') {
			return this.HKDF(nobleHashes.sha256, key, salt, info, size);
		}

		expand(key, max = 128){
			let slice = new Uint8Array()
			while(slice.length < (max || key.sum())){
				let salt = key.sum().to_bytes(16)
					key  = this.blake(key, {salt: salt, 
											dkLen: 32})
				slice = slice.append(key);
			}
			return this.derive(slice, key.sum().to_bytes(16), slice.length)
		}

		x(x, basepoint = 13) {
			return parseInt(Math.powMod(BigInt(basepoint), BigInt(x), BigInt(this.secret.length - 1)))
		}

		get(p=0, l=0, r=32){
			if(this.secret.length !== 0){
				let g = Math.pow(this.secret[Math.round(this.secret.length/2)], 2)
				let x = this.x(p, g)
				if(this.secret.slice(x,x + r).length == r)
					return this.secret.slice(x,x + r) 
				else 
					return this.secret.slice(x-r,x)
			}
			return new Uint8Array()
		}

		token(size = 32){
			if(this.secret.length !== 0){
				let random = this.random(size / 2)
				let secret = this.get(random.slice(0, random.length - 1).long(), 
									  random.slice(random.length - 1, random.length).long())
					secret = this.scrypt(secret, random, 
									   { N: 2 ** 8,
										 r: 8,
										 p: 1,
										 dkLen: random.length });
				return random.append(secret)
			}
			return new Uint8Array()
		}

		validate(token = new Uint8Array(32)) {
			let random = token.slice(0, token.length / 2)
				token  = token.slice(token.length / 2,token.length)
			let secret = this.get(random.slice(0, token.length - 1).long(), 
								  random.slice(token.length - 1, token.length).long())
				secret = this.scrypt(secret, random, 
								{ N: 2 ** 8,
								  r: 8,
								  p: 1, 
								  dkLen: random.length });
			return secret.equal(token)
		}

		aead(random, salt = new Uint8Array(16), size = 16){
			let secret = this.get(random.slice(0, 3).long(), 
									random.slice(3, 4).long())
			return this.blake(secret, {salt: salt, 
										dkLen: size})
		}

		salt(random, salt = new Uint8Array(16), size = 16){
			let secret = this.get(random.slice(4, 7).long(), 
									random.slice(7, 8).long())
			return this.scrypt(secret, salt, 
								{ N: 2 ** 16, 
									r: 8, 
									p: 1, 
									dkLen: size });
		}

		key(random, salt = new Uint8Array(16), size = 32){
			let secret = this.get(random.slice(8, 11).long(),
									random.slice(11,12).long())
			if(!salt.empty())
				return this.blake(secret, {salt: salt, 
												 dkLen: size})
			return secret
		}

		sign(data){
			if(!data.length)
				return new Uint8Array()
			return this.ed25519.sign(data, this.__signer.private)
		}

		verify(data, signature){
			return this.ed25519.verify(signature, data, this.client); // Default mode: follows ZIP215
		}

		async deriveKey(keyMaterial, salt, length = 32) {
			let key = await window.crypto.subtle.importKey('raw',
										keyMaterial, 
										'HKDF',
										false,
										["deriveBits", "deriveKey"]);
			return window.crypto.subtle.deriveKey({
									name: "HKDF",
									salt: salt,
									info: new Uint8Array(),
									hash: "SHA-256"},
									key,
									{ name: "AES-GCM", length: length * 8 },
									true,
									["encrypt", "decrypt"]);
		}

		async encrypt(data) {
			let iv   = this.random(12)
			let salt = this.salt(iv)
			let aead = this.aead(iv, salt)
			let key  = this.key(iv)
					key  = await this.deriveKey(key, salt)
			let ciphertext = await window.crypto.subtle.encrypt(
				{
					name: "AES-GCM",
					iv: iv,
					additionalData: aead,
					tagLength: parseInt(aead.length).to_bits()
				},
				key,
				data,
			);
			return iv.append(new Uint8Array(ciphertext));
		}

		async decrypt(data) {
			data = new Uint8Array(data)
			let iv = data.slice(0, 12)
			let salt = this.salt(iv)
			let aead = this.aead(iv, salt)
			let key  = this.key(iv)
					key  = await this.deriveKey(key, salt)
			let ciphertext = data.slice(12, data.byteLength)
			
			data = await window.crypto.subtle.decrypt(
				{
					name: "AES-GCM",
					iv: iv,
					additionalData: aead,
					tagLength: parseInt(aead.length).to_bits()
				},
				key,
				ciphertext,
			);
			return new Uint8Array(data);
		}
	}

	let object = undefined

	try {
		object = new relock()
	}
	catch(err) {
		console.error('Fatal object start.', err)
	}
	finally{
		if(object){
			__export(input_exports, {
				id:          () => object.id,
					id:          () => object.hash,
					token:       () => object.token.bind(object),
					encrypt:     () => object.encrypt.bind(object),
					decrypt:     () => object.decrypt.bind(object),
					sign:        () => object.sign.bind(object),
					verify:      () => object.verify.bind(object),
					clear:       () => object.clear.bind(object),
					request:     () => object.request.bind(object),
					validate:    () => object.validate.bind(object),
					token:       () => object.token.bind(object),
					screen:      () => object.screen,
					public:      () => object.public
				});

			return __toCommonJS(input_exports);
		}
	}
})();