window.addEventListener('XKeyEstablished', function(event) {
	const forms = document.querySelectorAll("form");
		  forms.forEach((form) => {
				let token = window.relock.token()
				var input = document.createElement("input");
					input.setAttribute("type", "hidden");
					input.setAttribute("name", "X-Key-Token");
					input.setAttribute("value", token.hexlify());
				form.appendChild(input);
				var input = document.createElement("input");
					input.setAttribute("type", "hidden");
					input.setAttribute("name", "X-Key-Signature");
					input.setAttribute("value", window.relock.sign(token).hexlify());
				form.appendChild(input);

				form.addEventListener('submit', function(event){
					let token = window.relock.token()
					let input = event.target.querySelector('input[name="X-Key-Token"]')
						input.setAttribute("value", token.hexlify());

					let signature = window.relock.token()
						input = event.target.querySelector('input[name="X-Key-Signature"]')
						input.setAttribute("value", window.relock.sign(token).hexlify());
				})
		  });
});