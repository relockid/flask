Array.prototype.base64url_encode = function() {
    return btoa(Array.from(new Uint8Array(this), b => String.fromCharCode(b)).join(''))
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/, '');
}

ArrayBuffer.prototype.base64url_encode = function() {
    return btoa(Array.from(new Uint8Array(this), b => String.fromCharCode(b)).join(''))
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/, '');
}

String.prototype.base64url_decode = function () {
    const m = this.length % 4;
    return Uint8Array.from(atob(
        this.replace(/-/g, '+')
            .replace(/_/g, '/')
            .padEnd(this.length + (m === 0 ? 0 : 4 - m), '=')
    ), c => c.charCodeAt(0))
}

Document.prototype.csrf = function () {
	let meta = document.querySelector("meta[name='csrf-token']")
	if(!!meta)
		if(!!meta.getAttribute("content"))
			meta = meta.getAttribute("content")
		else
			meta = String()
	return meta
}

Document.prototype.meta = function (name) {
	let meta = document.querySelector("meta[name='x-key-" + name + "']")
	if(!!meta)
		if(!!meta.getAttribute("content"))
			meta = meta.getAttribute("content").unhexlify()
		else
			meta = String()
	return meta
}

BigInt.prototype.bytes = function () {
		const big0 = BigInt(0)
		const big1 = BigInt(1)
		const big8 = BigInt(8)
		let big = this
		if (big < big0) {
		const bigint = (BigInt(big.toString(2).length) / big8 + big1) * big8
				bigint = big1 << bits
		big += prefix1
	}
	let hex = big.toString(16)
	if (hex.length % 2) {
		hex = '0' + hex
	}
	const len = hex.length / 2
	const u8 = new Uint8Array(len)
	var i = 0
	var j = 0
	while (i < len) {
		u8[i] = parseInt(hex.slice(j, j + 2), 16)
		i += 1
		j += 2
	}
	return u8.reverse()
}

Number.prototype.to_bytes = function (max) {
	if(!Number.isSafeInteger(Number(this))) {
		throw new Error("Number is out of range");
	}
	const size = this === 0 ? 0 : parseInt(this).byteLength();
	const bytes = new Uint8Array(size);
	let x = this;
	for (let i = (size - 1); i >= 0; i--) {
		const rightByte = x & 0xff;
		bytes[i] = rightByte;
		x = Math.floor(x / 0x100);
	}
	return new Uint8Array(max).fill((new Uint8Array(bytes.buffer)).reverse());
}

Number.prototype.to_bits = function () {
	return this * 8;
}

Number.prototype.bitLength = function () {
	return Math.floor(Math.log2(this)) + 1;
}

Number.prototype.byteLength = function () {
	return Math.ceil(parseInt(this).bitLength() / 8);
}

String.prototype.bytes = function () {
	return new TextEncoder().encode(this)
}

String.prototype.unhexlify = function () {
	 let result = [];
	 if(this.length){
		 let hexString = this;
		 while (hexString.length >= 2) { 
				 result.push(parseInt(hexString.substring(0, 2), 16));
				 hexString = hexString.substring(2, hexString.length);
		 }
	 }
	 return new Uint8Array(result);
}

String.prototype.hexlify = function () {
	if(this.length && this.hexlified())
		return this
	return String()
}

String.prototype.hexlified = function () {
	return /[0-9A-Fa-f]{6}/g.test(this);
}

Uint8Array.prototype.text = function() {
	return String.fromCharCode.apply(null, this);
}

Uint8Array.prototype.sum = function() {
	let total = 0,
				i = 0, length = this.length;
		while(i < this.length) 
			total += this[i++];
	return total
}

Uint8Array.prototype.append = function(array){
	let tmp = new Uint8Array(this.length + array.length);
		tmp.set(this);
		tmp.set(new Uint8Array(array), this.length);
	return tmp
}

Uint8Array.prototype.fill = function(array) {
	let i = 0;
		while(i < array.length){
			this[i] = array[i];
			i++;
		}
		return this
}

Uint8Array.prototype.equal = function(array) {
	if (!array || this.length !== array.length) {
		return false;
	}
	for (let i = 0; i < array.length; i++) {
		if (this[i] !== array[i]) {
			return false;
		}
	}
	return true;
}

Uint8Array.prototype.long = function() {
	let result = BigInt(0);
	for (let i = this.length - 1; i >= 0; i--) {
		result = result * BigInt(256) + BigInt(this[i]);
	}
	return result
}

Uint8Array.prototype.empty = function() {
	if(this.long() === 0n)
		return true
	return false
}

Uint8Array.prototype.hexlify = function(){ 
	return Array.from(this)
	.map((i) => i.toString(16).padStart(2, '0'))
	.join('');
}


Math.powMod = function(a, e, m) {
	// h/t https://umaranis.com/2018/07/12/calculate-modular-exponentiation-powermod-in-javascript-ap-n/
	if (m === 1n)
	return 0n;
	if (e < 0n)
	return Math.powMod(Math.modInv(a, m), -e, m);
	for (var b = 1n; e; e >>= 1n) {
	if (e % 2n === 1n)
		b = (b * a) % m;
	a = (a * a) % m;
	}
	return b;
}

Math.modInv = function(a, m) {
	// h/t https://github.com/python/cpython/blob/v3.8.0/Objects/longobject.c#L4184
	const m0 = m;
	var b = 1n, c = 0n, q, r;
	while (m) {
	[q, r] = [a/m, a%m];
	[a, b, c, m] = [m, c, b - q*c, r];
	}
	if (a !== 1n)
	throw new RangeError("Not invertible");
	if (b < 0n)
	b += m0;
	return b;
}

