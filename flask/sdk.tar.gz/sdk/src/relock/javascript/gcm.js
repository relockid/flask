	class GCM{

		__material = new Uint8Array()

		constructor(...args){
			if(args[0] && !this.key)
				this.key = this.importKey(args[0])
			if(args[1])
				this.aead = new Uint8Array(args[1])
			else
				this.aead = new Uint8Array(16)
		}

		async importKey(key) {
			this.__material = new Uint8Array(key)
			return window.crypto.subtle.importKey('raw',
										this.__material, 
										{ name: "AES-GCM", 
										  length: parseInt(this.__material.length).to_bits() },
										false,
										["encrypt", "decrypt"]);
		}

		async grindKey(salt = new Uint8Array(16), info = new Uint8Array()){
			let key = await window.crypto.subtle.importKey('raw',
										this.__material, 
										'HKDF',
										false,
										["deriveBits", "deriveKey"]);
			this.key = await window.crypto.subtle.deriveKey({
									name: "HKDF",
									salt: salt,
									info: info,
									hash: "SHA-256"},
									key,
									{ name: "AES-GCM", length: key.algorithm.length },
									true,
									["encrypt", "decrypt"]);
		}

		async encrypt(data) {
			let iv = nobleHashes.utils.randomBytes(12)
			return await window.crypto.subtle.encrypt(
				{
					name: "AES-GCM",
					iv: iv,
					additionalData: this.aead,
					tagLength: parseInt(this.aead.length).to_bits()
				},
				await this.key,
				data,
			).then((ciphertext) => {
				return iv.append(new Uint8Array(ciphertext));
			  })
			 .catch((error) => {
				throw new Error('Encryption faild!')
			  });
		}

		async decrypt(data) {
			return await window.crypto.subtle.decrypt(
				{
					name: "AES-GCM",
					iv: data.slice(0, 12),
					additionalData: this.aead,
					tagLength: parseInt(this.aead.length).to_bits()
				},
				await this.key,
				data.slice(12, data.byteLength),
			).then((data) => {
				return new Uint8Array(data)
			 })
			 .catch((error) => {
			 	return new Uint8Array()
			 });
		}
	}